# 연속성 브리지 내장 도우미 소스·재링크 키트

이 키트의 앱·도우미 소스는 2026-09-14 Galaxy의 오래된 무선 디버깅 포트 검색을
수정한 `continuity-bridge-android-embedded-debug.apk`(6,016,597 bytes)에
대응합니다. 해당 APK의 SHA-256은 다음과 같습니다.

```text
40042909e8cff6c292f54c02161fa43597d63f97e038d0e0798bdaacba4a86c4
```

앱 입력 105개(Java 87개, AIDL 2개, manifest 1개, 리소스 15개)와 libadb 패치
Java 1개는 해당 APK의 기존 대응 키트 및 현재 저장소와 바이트가 같습니다.
의존성 소스 archive 6개도 원본 그대로 보존했습니다. **빌드·검사 스크립트와 문서는
2026-09-14의 환경 변수 지원 방식으로 갱신했습니다.** 모든 파일이 과거 APK를
만들 때 사용한 그대로라고 주장하지 않습니다. 대응 입력과 갱신 범위는
`BUILD-INFO.txt`에 구분해 기록했습니다.

앱·도우미 소스, AIDL, manifest·리소스, 빌드 진입점·도구 선택 스크립트, 빌드가
실제 호출하는 검사 3개, 자동 검색 회귀 테스트, 의존성 잠금·패치·라이선스·원본
소스를 포함합니다. 전체 파일 목록은 `INVENTORY.txt`, 파일별 해시는
`SHA256SUMS`에 있습니다. APK, 생성 클래스·DEX, 캐시, 서명 키는 포함하지 않습니다.

압축을 푼 이 디렉터리에서 무결성을 확인합니다. `SHA256SUMS`는 자신을 제외한
모든 일반 파일을 검사하며, `INVENTORY.txt`는 두 목록 파일도 포함합니다.

```sh
shasum -a 256 -c SHA256SUMS
(cd continuity-bridge/android/dependencies/upstream-sources && shasum -a 256 -c SHA256SUMS)
```

[도우미 안내](continuity-bridge/android/EMBEDDED_HELPER.md)는 기능과 기존 실행 기록을
설명합니다. 이 키트에는 전체 저장소의 루트 README, `continuity-bridge/BUILD.md`,
나머지 호스트·생명주기·계측 테스트, 테스트 APK·로그, 이전 Shizuku 문서는 없습니다.
빌드 방법은 지금 읽는 이 키트의 README를 사용하세요.

## 빌드 환경

진입점은 `continuity-bridge/android/build.sh`입니다. Gradle 앱 빌드가 아니라
`aidl` → `aapt2` → `javac` → `d8` → `zipalign` → `apksigner` 순서의 수동 빌드입니다.
SDK Platform 35, Build-Tools 35.0.0, SDK Command-line Tools의 `apkanalyzer`,
JDK 17 이상을 준비합니다. min SDK는 29, target SDK는 35입니다. 무선 디버깅
페어링의 사용 대상은 Android 11 이상입니다. SDK/JDK/NDK/CMake는 포함하지 않습니다.

`build.sh`와 도구 검사는 같은 `toolchain.sh`를 사용합니다. 개인 경로를
스크립트에 편집하는 대신 다음 환경 변수를 지정합니다.

| 환경 변수 | 선택하는 값 |
| --- | --- |
| `ANDROID_HOME` | SDK 루트. 없으면 `ANDROID_SDK_ROOT`, 이후 일반 설치 위치를 찾음 |
| `JAVA_HOME` | JDK/JBR Home. 없으면 Android Studio JBR와 macOS `java_home`을 찾음 |
| `CONTINUITY_ANDROID_BUILD_TOOLS` | 선택 사항: Build-Tools 디렉터리. 기본은 SDK의 `build-tools/35.0.0` |
| `CONTINUITY_ANDROID_PLATFORM_DIR` | 선택 사항: `android.jar`와 `framework.aidl`이 있는 디렉터리. 기본은 SDK의 `platforms/android-35` |
| `CONTINUITY_APKANALYZER` | 선택 사항: `apkanalyzer` 실행 파일. 기본은 SDK의 `cmdline-tools/latest/bin/apkanalyzer` |
| `CONTINUITY_DEBUG_KEYSTORE` | 디버그 서명 키. 다음 우선순위는 `KEYSTORE`, 그다음 `$HOME/.android/debug.keystore` |
| `PYTHON3` | manifest 검사에 사용할 Python 3 실행 파일. 기본은 `/usr/bin/python3` |

경로는 절대 경로로 지정하세요. 개별 Platform/Build-Tools 경로를 지정해도 SDK
루트가 필요합니다. Build-Tools에는 `core-lambda-stubs.jar`도 있어야 합니다.

POSIX shell, Perl, Python 3 표준 라이브러리, OpenSSL, `curl`, `shasum`, `zip`,
`unzip`, `find`, `awk`, `grep`, `sort`, `paste`, `cmp`를 사용합니다. 일부 실행 경로는
`/usr/bin/perl`, `/usr/bin/zip`, `/usr/bin/unzip`입니다. 환경 변수 지원은 다른 OS의
실행 검증과 다릅니다. Windows 그대로 실행하거나 모든 OS에서 수정 없이 빌드할 수
있다고 검증한 키트는 아닙니다.

디렉터리 배치를 유지하면 빌드의 루트는 스크립트 위치로 계산됩니다.
`android/build/shizuku`는 남아 있는 디렉터리 이름이며 외부 Shizuku runtime 입력은
없습니다. 매 빌드가 이 디렉터리를 지우므로 수정 소스와 교체 바이너리는 밖에 두세요.

## 본인 키로 재빌드

아래 SDK·JDK 경로를 본인 설치 위치로 바꾸고 키트 루트에서 실행합니다.
도구 선택 결과는 이후 재링크 예제에서도 사용합니다.

```sh
KIT_ROOT=$(pwd)
ANDROID_DIR="$KIT_ROOT/continuity-bridge/android"
export ANDROID_HOME="/absolute/path/to/android-sdk"
export JAVA_HOME="/absolute/path/to/jdk"
export CONTINUITY_DEBUG_KEYSTORE="$HOME/.android/continuity-relink-debug.keystore"
. "$ANDROID_DIR/toolchain.sh"
continuity_android_tools
RELINK_JAVA_HOME="$JAVA_HOME"
RELINK_TOOLS_DIR="$TOOLS_DIR"
RELINK_PLATFORM_JAR="$PLATFORM_JAR"
```

빌드할 때 지정한 키가 없으면 로컬에서 새로 만들고, 이미 있으면 검사해 사용합니다.
alias는 `androiddebugkey`, 공개 개발용 기본 비밀번호는 `android`입니다. 다른
alias나 비밀번호를 쓰려면 본인 사본의 키 검사와 `apksigner` 인수도 조정해야 합니다.
원래 프로젝트의 서명 키, 로컬 ADB 개인 키, 설정·인증 정보는 제공하지 않습니다.

빌드 제한 시간은 180초입니다. 최초 다운로드가 이 시간을 소모하지 않도록 먼저
별도 목적지로 의존성을 받습니다. 원본 archive는 키트에 포함되지만 실행 바이너리와
Maven POM은 HTTPS로 받으므로 인터넷이 필요합니다. 다운로드와 캐시 재사용 때마다
`embedded.lock`의 해시를 검사합니다.

```sh
export CONTINUITY_EMBEDDED_CACHE="$KIT_ROOT/.relink-cache"
"$ANDROID_DIR/dependencies/embedded-fetch.sh" "$KIT_ROOT/relink-work/original-dependencies"
"$ANDROID_DIR/build.sh"
```

출력은 키트 안의 `outputs/continuity-bridge-android-embedded-debug.apk`와
`.apk.sha256`입니다. 빌드 중 `verify-production-wiring.sh`, `verify-manifest-source.sh`,
`verify-adapter-boundary.sh` 및 ZIP alignment 검사를 실행합니다. 별도로 확인하려면:

```sh
(cd "$KIT_ROOT/outputs" && shasum -a 256 -c continuity-bridge-android-embedded-debug.apk.sha256)
"$RELINK_TOOLS_DIR/apksigner" verify --verbose "$KIT_ROOT/outputs/continuity-bridge-android-embedded-debug.apk"
"$RELINK_TOOLS_DIR/zipalign" -c -P 16 4 "$KIT_ROOT/outputs/continuity-bridge-android-embedded-debug.apk"
```

자동 검색 회귀 테스트는 포함되어 있으며 같은 JDK 선택을 사용합니다.

```sh
"$ANDROID_DIR/run-embedded-discovery-tests.sh"
```

본인 키로 만든 APK는 다른 키로 서명된 기존 설치본 위에 업데이트할 수 없습니다.
원래 키 없이도 빈 에뮬레이터나 해당 패키지가 없는 본인 테스트 기기에 설치해
수정본을 실행할 수 있습니다. 기존 설치본을 제거하면 앱 데이터가 지워질 수 있습니다.
초기 설치 예시는 `adb -s YOUR_TEST_SERIAL install PATH_TO_REBUILT_APK`입니다.
앱에서 새로 페어링하고, 공유 기능에는 본인의 릴레이 설정을 사용하세요.
새 키와 도구·ZIP 메타데이터로 만든 APK가 첫머리 APK 해시와 같다고 약속하지 않습니다.

## Android 공개 CA

기본 CA는 `app/src/main/res/raw/continuity_local_ca.pem`의 공개 테스트 인증서이며,
빌드가 알려진 SHA-256을 검사합니다. `runtime/`은 빌드에 필요하지 않습니다.
키트의 `continuity-bridge/runtime/tls/ca.pem`은 이전 키트의 공개 인증서 사본으로만
보존했습니다. 공개 HTTPS 주소에 빈 핀을 사용하면 시스템 신뢰 저장소로 연결하므로
이 로컬 테스트 CA를 사용하지 않습니다.

본인의 로컬 CA를 사용하려면 받은 사본의 앱 리소스를 본인의 공개 PEM CA로 교체하고,
같은 인증서를 `CONTINUITY_ANDROID_CA_PEM`으로 명시합니다.

```sh
RELINK_CA_PEM="/absolute/path/to/public-ca.pem"
cp "$RELINK_CA_PEM" "$ANDROID_DIR/app/src/main/res/raw/continuity_local_ca.pem"
export CONTINUITY_ANDROID_CA_PEM="$RELINK_CA_PEM"
"$ANDROID_DIR/build.sh"
```

빌드는 파일이 유효한 공개 CA 인증서만 담았는지와 앱 리소스의 바이트 일치를 검사합니다.
개인 키는 리소스에 넣지 마세요. CA를 바꾸면 첫머리 APK의 원본 입력과 달라집니다.
새 릴레이의 서버 인증서 핀은 앱에 별도로 설정해야 합니다.

## SPAKE2 Java·JNI·C 수정과 재링크

원본 잠금 해시·다운로드 캐시를 수정하지 않고 별도 작업 트리와 본인 사본의 빌드
스크립트에서 교체 입력을 적용합니다. 수정한 라이브러리 소스와 변경 내역도 보존하고,
Java 클래스/JNI 이름과 호출 인터페이스를 호환되게 유지하세요.
앞에서 지정한 `KIT_ROOT`, `ANDROID_DIR`, `RELINK_JAVA_HOME`, `RELINK_PLATFORM_JAR`를 사용합니다.

```sh
RELINK_WORK="$KIT_ROOT/relink-work"
UPSTREAM="$ANDROID_DIR/dependencies/upstream-sources"
SPAKE_TREE="$RELINK_WORK/spake2-java"
RELINK_INPUTS="$RELINK_WORK/replacement"
mkdir -p "$SPAKE_TREE" "$RELINK_INPUTS/jars"
tar -xzf "$UPSTREAM/spake2-java-7615ddd680b990e14513ebb66eac4cb0dbf82464.tar.gz" \
  -C "$SPAKE_TREE" --strip-components=1
mkdir -p "$SPAKE_TREE/android/src/main/cpp/spake2-c"
tar -xzf "$UPSTREAM/spake2-c-0d15933e5ba3e662cb01245a7ac0dc9fca3eac31.tar.gz" \
  -C "$SPAKE_TREE/android/src/main/cpp/spake2-c" --strip-components=1
```

Android Java 구현은 `android/src/main/java/.../Spake2Context.java`와 `Spake2Role.java`,
JNI wrapper는 `android/src/main/cpp/spake2_jni.cpp`입니다. 다른 `java/` 모듈의 순수
Java 구현과 혼합하지 않습니다. 수정한 Android Java를 컴파일하려면:

```sh
mkdir -p "$RELINK_WORK/spake2-classes"
find "$SPAKE_TREE/android/src/main/java" -name '*.java' -print | LC_ALL=C sort > "$RELINK_WORK/spake2-java-sources.txt"
"$RELINK_JAVA_HOME/bin/javac" -encoding UTF-8 -source 8 -target 8 \
  -bootclasspath "$RELINK_PLATFORM_JAR" \
  -classpath "$RELINK_WORK/original-dependencies/jars/annotation-1.3.0.jar" \
  -d "$RELINK_WORK/spake2-classes" @"$RELINK_WORK/spake2-java-sources.txt"
"$RELINK_JAVA_HOME/bin/jar" cf "$RELINK_INPUTS/jars/spake2-android-2.2.1.jar" \
  -C "$RELINK_WORK/spake2-classes" .
```

native 소스도 바꿨다면 Android NDK와 CMake 3.22.1을 별도로 준비합니다. 다음은
포함된 upstream CMakeLists에 맞춘 예시이며, 이 키트 갱신에서 실행하지 않았습니다.
원래 APK는 잠긴 upstream `.so`를 사용했습니다. 16 KB 설정과 도구 버전은
[Android의 페이지 크기 안내](https://developer.android.com/guide/practices/page-sizes)를 확인하세요.

```sh
RELINK_NDK="/absolute/path/to/android-ndk"
RELINK_CMAKE="/absolute/path/to/android-sdk/cmake/3.22.1/bin/cmake"
for abi in arm64-v8a x86_64; do
  mkdir -p "$RELINK_INPUTS/lib/$abi"
  "$RELINK_CMAKE" -S "$SPAKE_TREE/android/src/main/cpp" -B "$RELINK_WORK/native-$abi" \
    -DCMAKE_TOOLCHAIN_FILE="$RELINK_NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$abi" -DANDROID_PLATFORM=android-29 -DANDROID_STL=none \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_LIBRARY_OUTPUT_DIRECTORY="$RELINK_INPUTS/lib/$abi" \
    '-DCMAKE_SHARED_LINKER_FLAGS=-Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384'
  "$RELINK_CMAKE" --build "$RELINK_WORK/native-$abi"
done
```

`CMAKE_LIBRARY_OUTPUT_DIRECTORY`는 upstream의 빌드 후 strip 명령에도 필요합니다.
새 C++ 기능이 표준 라이브러리를 요구하면 STL 선택과 런타임 배포도 조정해야 합니다.
기존 소스는 추가 shared C++ runtime을 요구하지 않습니다. Java만 수정했다면 원본
`.so`를 복사해 사용합니다. native를 재빌드한 경우 다음 복사는 실행하지 않습니다.

```sh
for abi in arm64-v8a x86_64; do
  mkdir -p "$RELINK_INPUTS/lib/$abi"
  cp "$RELINK_WORK/original-dependencies/lib/$abi/libspake2.so" "$RELINK_INPUTS/lib/$abi/libspake2.so"
done
```

본인 사본의 `build.sh`에서 `embedded-fetch.sh` 호출 직후, `DEPENDENCY_CP` 계산 직전에
다음을 넣습니다. 원본 다운로드와 캐시를 바꾸지 않고 빌드용 복사본만 교체합니다.

```sh
RELINK_INPUTS="$ROOT/relink-work/replacement"
cp "$RELINK_INPUTS/jars/spake2-android-2.2.1.jar" "$BUILD/dependencies/jars/spake2-android-2.2.1.jar"
for abi in arm64-v8a x86_64; do
  cp "$RELINK_INPUTS/lib/$abi/libspake2.so" "$BUILD/dependencies/lib/$abi/libspake2.so"
done
```

같은 `build.sh`를 실행하면 명시된 D8·ZIP 입력 이름으로 수정한 SPAKE2가 포함됩니다.
호환 파일명은 수정본이 원본 잠금 artifact와 같다는 뜻이 아닙니다. 수정 소스,
새 JAR/`.so` 해시, NDK 버전·빌드 옵션·변경 내역을 기록하고 수정 APK는 별도 이름으로
배포하세요. `embedded.lock`은 원본 다운로드의 출처를 보존합니다.

## 소스·라이선스

`continuity-bridge/android/dependencies/embedded-licenses/`에 Apache-2.0, LGPL-3.0,
GPL-3.0 및 컴포넌트 고지 전문과 출처를 포함했습니다. libadb의 선택한 Apache-2.0
조건과 개별 파일 고지를 보존하며, SPAKE2 Java는 LGPL-3.0입니다. 적용 조건은
포함된 라이선스 전문을 따릅니다. 이 키트는 앱 전체에 새 라이선스를 부여하지 않습니다.
소스·라이선스·재링크 자료를 함께 보관하고 수정 라이브러리의 변경 내용을 기록하세요.

원본 소스 archive 6개는 `dependencies/upstream-sources/`에 있고 `embedded.lock`과
SHA-256이 일치합니다. SPAKE2-C 서브모듈 archive도 포함됩니다. Conscrypt에 사용된
BoringSSL의 정확한 revision과 소스 URL은 `embedded-licenses/SOURCES.txt`에 있습니다.
BoringSSL 전체 source archive는 포함하지 않습니다. SPAKE2 교체를 위한 앱 재링크는
Conscrypt를 다시 컴파일하지 않고 잠긴 Conscrypt 바이너리를 내려받아 사용합니다.

Conscrypt 원본 소스에는 공개 upstream 테스트용 개인 키 fixture와 테스트 코드의
키 상수가 있습니다. 원본 archive SHA를 유지하기 위해 그대로 포함했고,
`UPSTREAM-TEST-KEYS.txt`에 위치와 검사 범위를 기록했습니다. 프로젝트의 서명·운영·
로컬 ADB 키가 아니며 실제 인증에 사용하면 안 됩니다.

## 확인 범위

이번 갱신에서는 APK 대응 앱 입력·패치의 바이트 일치, 원본 archive 6개의 잠금
해시, 새 ZIP 무결성·파일 목록·내부 체크섬, 개인 경로·자격증명 패턴을 확인했습니다.
빌드 도구와 문서를 갱신했지만 이 키트 작업에서 APK를 다시 빌드하거나 기기를
조작하지 않았습니다. 새 키로 빌드한 APK의 바이트 해시 재현을 주장하지 않습니다.
SPAKE2 native 재빌드 예제와 x86_64 실행, 다른 OS 빌드는 이번 실행 검증 범위가 아닙니다.

2026-09-14의 해당 APK는 Galaxy SM-S948N / Android 16 / API 36에서 앱 자체 무선
ADB 페어링, UID 2000 도우미, Galaxy→Mac 텍스트 10/10회 및 PNG/JPEG 바이트 일치를
확인한 기록이 있습니다. Mac→Galaxy JPEG 붙여넣기는 바이트가 일치했지만 no-echo
검사에 실패해 양방향 이미지 회귀 검증이 완전히 통과한 상태는 아닙니다. 이 Galaxy
빌드의 재부팅·잠금·도우미 복구는 검증하지 않았습니다.

2026-09-13의 API 37 arm64 / 16 KB 페이지 에뮬레이터 검증은 별도 과거 기록입니다.
그 에뮬레이터의 native 로딩·페어링·복사·재부팅 복구 성공을 현재 Galaxy 결과로 대신하지
않습니다. SPAKE2 원본 GNU_RELRO 끝 주소의 정적 16 KB 경고도 남아 있습니다.
자세한 기록과 한계는 도우미 안내와 의존성 안내에 보존했습니다.
